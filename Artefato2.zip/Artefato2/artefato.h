typedef struct tadLista TadLista;
//struct das palavras
typedef struct palavra{
    char *word;
    struct tadLista *lista;
}Palavra;

//struct da  lista encadeada
struct tadLista{
    int linha;
    int quantidade_vezes;
    struct tadLista *prox;
};


Palavra *encontrar(Palavra **vetor, char *word, int numero_palavras);

int igual(char *c1, char *c2);

void inserir(Palavra *w,int linha);

void limpar(TadLista *p);
