#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <string.h>
#include "artefato.h"

#define MAXLEN 2097152 // 2MB,  tamanho maximo de um arquivo

int main(void)
{

    //-------------------------------------------------//
    //cria��o do arquivo
    FILE *arquivo;
    arquivo = fopen("artefato.txt","r");

    if(arquivo == NULL){
        printf("\nerro na abertura do arquivo\n");
        system("pause");
        exit(1);
    }
