#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "artefato.h"

int igual(char *c1, char *c2){
    int i=0;
    while(1){
        if(c1[i] != c2[i]){
            return 0;
        }

        if(c1[i] == '\0'){
            break;
        }
        i++;
    }
    return 1;
}
Palavra *encontrar(Palavra **vetor, char *word, int numero_palavras){
    int i;
    for(i=0; i<numero_palavras;i++){
        if(igual(vetor[i]->word,word)){
            return vetor[i];
        }
    }
    return 0;
}

void inserir(Palavra *w,int linha){
    TadLista *lista = w->lista;
    while(lista != 0 && lista->linha != linha){
        lista = lista->prox;
    }

    if(lista == 0){
        TadLista *novo = (TadLista*)malloc(sizeof(TadLista));
        novo->linha = linha;
        novo->quantidade_vezes = 1;
        novo->prox = 0;

        if(w->lista == 0){
            w->lista = novo;
        }else{
            lista = w->lista;
            while(lista->prox != 0){
                lista = lista->prox;
            }
            lista->prox = novo;
        }

    }else{
        lista->quantidade_vezes++;
    }
}

void limpar(TadLista *p){
    while(p != 0){
        TadLista *p2 = p->prox;
        free(p);
        p = p2;
    }
}

